import Animacao from "./Tools/Animacao";

function SecaoProvaSocial() {
    return ( 
        <section className="provaSocial">
            <h2>Seção prova social</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, dolor ea. Dolorum laudantium accusamus ad? Hic nesciunt voluptates ducimus architecto, rem vitae delectus excepturi illum? Ducimus tenetur rerum aspernatur placeat.
            Tenetur repudiandae ea, natus accusamus, est rem eligendi ipsa laboriosam blanditiis sit vero debitis. Quasi rerum tempora voluptatem consequatur dicta! Quos repellendus beatae delectus tenetur facere a consequatur, debitis laborum?
            Autem tempora corporis eos sunt perspiciatis et ad, ea facere facilis, fuga, sint ut dolorem libero in. Cumque similique, modi, vero adipisci optio nulla necessitatibus sit rerum veritatis quidem temporibus.
            Et reiciendis soluta delectus, quasi eos doloremque quisquam quo? Corporis expedita qui repellendus ullam temporibus perspiciatis nulla, vitae nihil velit fugit nostrum maxime nisi omnis aliquid eum quisquam quo facilis.</p>
            <Animacao css_identifier=".provaSocial" type="fade"/>
        </section>
     );
}

export default SecaoProvaSocial
;