function FaleConosco() {
    return ( 
        <section>
            <h2>Fale Conosco</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos commodi nesciunt distinctio modi cumque. Perferendis doloribus quis consectetur numquam animi labore nam veniam nulla rem blanditiis. Facilis, autem. Molestiae, maxime.</p>
        </section>
        
    );
}

export default FaleConosco;