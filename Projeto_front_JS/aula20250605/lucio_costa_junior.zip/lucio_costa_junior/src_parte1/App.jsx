import { useState } from 'react'
import Contador from './Componentes/Contador'
import Ranking from './Componentes/Ranking/Ranking'


function App() {
  return (
    <>
    {/* <Contador/> */}
    <Ranking/>
    </>
  )
}

export default App
