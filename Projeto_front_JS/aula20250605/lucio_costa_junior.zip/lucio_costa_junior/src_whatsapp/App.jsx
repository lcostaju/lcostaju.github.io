import { useState } from 'react'
import Whatsapp from './Whatsapp'


function App() {
 

  return (
    <>
    <Whatsapp/>
    </>
  )
}

export default App
