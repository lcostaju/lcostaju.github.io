const conteudo = {
    texto: `Viva Aventuras é uma operadora de ecoturismo especializada em turismo de aventura
com base na segurança, sustentabilidade e inclusão das mulheres no Turismo de Aventuras
e ao esporte atraves dos curso de Rapel. Fundada em 2019 ,opera na região do Triângulo Mineiro e Canastra. Nestes 6 anos realizou vários curso de Rapel esportivo e dese de 2023 oferece tambem Cursos profissionais como Trabalho em Altura conforme Nr35. Tornando 
profissionais com alto padrão técnico e também realizamos Consultoria e treinamentos profissionais
pecializados para empresas no setor de Limpeza e Conservação.
Nosso impacto vai além da adrenalina: preservamos o meio ambiente, promovemos o
desenvolvimento comunitário e criamos experiências que unem corpo, mente e espírito. 
Mais que aventura A Viva é conexão, consciência e transformação`,
    titulo: "Quem somos!",
    img: "image.png"

}

export default conteudo;