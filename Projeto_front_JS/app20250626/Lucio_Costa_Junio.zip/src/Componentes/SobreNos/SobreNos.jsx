function SobreNos(){
    return(

        <section>
            <h2>Sobre nos ...........</h2>
        </section>
    )
}

export default SobreNos;