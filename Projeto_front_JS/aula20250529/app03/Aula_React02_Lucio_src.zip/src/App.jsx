import React from 'react';
import Formulario1 from './components/Formulario1';
import Formulario2 from './components/Formulario2';
import Formulario3 from './components/Formulario3';
import FormularioBonus from './components/FormularioBonus';

function App() {
  return (
    <>
      <Formulario1/>
      <Formulario2/>
      <Formulario3/>
      <FormularioBonus/>
    </>

  );
}

export default App;